"""
Aggregation utilities for the block wall estimator.

This module provides a helper to roll up quantity results across multiple
segments.  The aggregator simply sums the counts and volumes for each material
category.  It does not handle pricing—costs are meant to be applied in a
separate layer (e.g., using a cost database).

To aggregate, call ``aggregate_quantities`` with a list of ``QuantityResults``
instances (one per component) and obtain a dictionary of totals.  The keys in
the returned dictionary correspond to the fields of ``BlockCounts``,
``RodCounts`` and ``GroutVolume``.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Dict, Iterable

from .models import QuantityResults


def aggregate_quantities(results: Iterable[QuantityResults]) -> Dict[str, float]:
    """Sum quantities across multiple ``QuantityResults``.

    Parameters
    ----------
    results : iterable of QuantityResults
        Quantity results to aggregate.  These may come from different
        segments/components.

    Returns
    -------
    dict
        Aggregated totals.  Keys include ``standard_blocks``, ``bond_beam_blocks``,
        ``half_blocks``, ``total_blocks``, ``tension_rods``, ``extension_rods``,
        ``ladder_wire_lf``, ``grout_cells_filled``, and ``grout_cy``.
    """
    totals: Dict[str, float] = defaultdict(float)
    for qty in results:
        bc = qty.block_counts
        rc = qty.rod_counts
        gv = qty.grout
        totals['standard_blocks'] += bc.standard
        totals['bond_beam_blocks'] += bc.bond_beam
        totals['half_blocks'] += bc.half
        totals['total_blocks'] += bc.total
        totals['courses'] += bc.courses
        totals['tension_rods'] += rc.tension_rods
        totals['extension_rods'] += rc.extension_rods
        totals['ladder_wire_lf'] += rc.ladder_wire_lf
        totals['grout_cells_filled'] += gv.cells_filled
        totals['grout_cy'] += gv.volume_cy
    return dict(totals)


__all__ = ["aggregate_quantities"]