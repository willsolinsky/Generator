"""
Data models for the block wall estimator.

These dataclasses represent the primary entities manipulated by the estimator:

* ``LabelCounts`` tallies any special labels (corners, miters, control joints, ends) attached
  to a take‑off row.  These labels influence block counts (e.g., half blocks at corners) and
  rebar placement (e.g., rods at control joints).

* ``WallComponent`` describes one portion of a wall segment.  A segment may include a
  retaining portion (``RET``) and an optional wall‑on‑top portion (``WOT``) stacked on top of
  the retaining stem.  Each component records its width (6 in or 8 in are common),
  system type (e.g., ``CMU`` or ``PROTO``) and height in feet.

* ``NormalizedSegment`` packages the parsed information from a Bluebeam description into a
  structured form.  It includes an identifier for reference, the original label string,
  optional retaining and wall‑on‑top components, the measured linear footage, and the
  associated label counts.

* ``BlockCounts`` holds the results of block quantity calculations for a single component.
  Standard blocks are full‑sized blocks, bond‑beam blocks are specialized units used to
  form bond beams, and half blocks are counted separately because they are typically
  purchased as distinct pieces.  Total block count is the sum of the three types.  The
  ``courses`` field stores the number of block courses required for the component's height.

* ``RodCounts`` encapsulates the number of post‑tension rods (for Proto systems) and
  extension rods required to reach the design height.  CMU systems typically have zero
  rods.  ``ladder_wire_lf`` tracks the linear footage of ladder wire used in horizontal
  reinforcement, assuming one wire per course.

* ``GroutVolume`` represents grout usage in cubic yards.  ``cells_filled`` records how many
  block cells are filled with grout (useful for QA and test comparison), while
  ``volume_cy`` is the corresponding volume.  The estimator assumes a simple fill factor
  based on system type and block width; more detailed schedules can override this via
  schedule lookups.

* ``QuantityResults`` ties together all quantity outputs for a single component.  This
  includes block counts, rod counts and grout volume.  When applied to both the retaining
  and wall‑on‑top portions of a segment, it yields the complete material list for that
  segment.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class LabelCounts:
    """Counts of special labels attached to a segment."""

    corner_count: int = 0
    miter_count: int = 0
    control_joint_count: int = 0
    end_count: int = 0


@dataclass
class WallComponent:
    """Represents a single wall component (retaining or wall‑on‑top)."""

    type: str  # 'RET' or 'WOT'
    width_in: int  # block width in inches (e.g. 6 or 8)
    system: str  # system type (e.g. 'CMU', 'PROTO')
    height_ft: float  # wall height in feet


@dataclass
class NormalizedSegment:
    """Normalized representation of a Bluebeam take‑off row."""

    segment_id: str
    raw_label: str
    ret: Optional[WallComponent]
    wot: Optional[WallComponent]
    length_lf: float
    labels: LabelCounts = field(default_factory=LabelCounts)

    def has_component(self, comp: str) -> bool:
        """Return True if the segment has the requested component ('ret' or 'wot')."""
        return (comp == 'ret' and self.ret is not None) or (comp == 'wot' and self.wot is not None)

    def get_component(self, comp: str) -> Optional[WallComponent]:
        """Return the WallComponent for the requested component or None."""
        return self.ret if comp == 'ret' else self.wot


@dataclass
class BlockCounts:
    """Quantities of blocks required for a component."""

    standard: int = 0
    bond_beam: int = 0
    half: int = 0
    total: int = 0
    courses: int = 0


@dataclass
class RodCounts:
    """Counts of rods and ladder wire for a component."""

    tension_rods: int = 0
    extension_rods: int = 0
    ladder_wire_lf: float = 0.0


@dataclass
class GroutVolume:
    """Grout usage in cubic yards."""

    cells_filled: int = 0
    volume_cy: float = 0.0


@dataclass
class QuantityResults:
    """Aggregated quantity outputs for a component."""

    block_counts: BlockCounts = field(default_factory=BlockCounts)
    rod_counts: RodCounts = field(default_factory=RodCounts)
    grout: GroutVolume = field(default_factory=GroutVolume)
