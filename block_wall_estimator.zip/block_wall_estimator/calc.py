"""
Quantity calculations for the block wall estimator.

This module implements the core logic for converting normalized segments into
material quantities.  It computes block counts, rod counts and grout volumes
based on the geometry of the wall, the system type (CMU or Proto), and a few
simple schedule parameters defined in ``schedules``.  Although simplified, the
calculations illustrate how the workbook formulas can be encoded in Python.

The public function ``calculate_quantities`` accepts a ``NormalizedSegment`` and
returns a dictionary mapping ``'ret'`` and ``'wot'`` to ``QuantityResults``
instances.  Each instance contains block counts, rod counts and grout volume
for that component.  If a component is absent, it is omitted from the result.

You can build upon these functions to add more detailed logic (pilaster
quantities, footing concrete volumes, rebar sizes, etc.) as those formulas
become available.
"""

from __future__ import annotations

import math
from typing import Dict

from .models import NormalizedSegment, BlockCounts, RodCounts, GroutVolume, QuantityResults
from .geometry import height_to_courses, blocks_per_row
from .schedules import (
    BOND_BEAM_SPACING_COURSES,
    HALF_BLOCKS_PER_CORNER_PER_COURSE,
    REBAR_SPACING_PROTO_FT,
    EXTENSION_ROD_COURSE_THRESHOLD,
    GRUOT_FILL_FACTOR_PROTO_FT3,
    GRUOT_FILL_FACTOR_CMU_FT3,
)


def _calculate_block_counts(segment: NormalizedSegment, comp_key: str) -> BlockCounts:
    """Calculate block quantities for a single component of a segment.

    Parameters
    ----------
    segment : NormalizedSegment
        Segment containing the component.
    comp_key : str
        Either ``'ret'`` or ``'wot'``.

    Returns
    -------
    BlockCounts
        Counts of standard, bond‑beam and half blocks for the component.
    """
    component = segment.get_component(comp_key)
    if component is None:
        return BlockCounts()

    height_ft = component.height_ft
    length_ft = segment.length_lf
    courses = height_to_courses(height_ft)

    # Compute blocks per row and round up to whole blocks
    blocks_per_row_exact = blocks_per_row(length_ft)
    blocks_per_row_int = math.ceil(blocks_per_row_exact)

    # Determine number of bond beam rows
    bond_beam_rows = max(1, math.ceil(courses / BOND_BEAM_SPACING_COURSES))
    standard_rows = courses - bond_beam_rows

    # Standard blocks fill the remaining courses
    standard_blocks = standard_rows * blocks_per_row_int

    # Bond beam blocks: one full row per bond beam course
    bond_beam_blocks = bond_beam_rows * blocks_per_row_int

    # Half blocks: one half block per corner per course (two halves make one full block)
    half_blocks = segment.labels.corner_count * courses * HALF_BLOCKS_PER_CORNER_PER_COURSE

    total_blocks = standard_blocks + bond_beam_blocks + half_blocks

    return BlockCounts(
        standard=standard_blocks,
        bond_beam=bond_beam_blocks,
        half=half_blocks,
        total=total_blocks,
        courses=courses,
    )


def _calculate_rod_counts(segment: NormalizedSegment, comp_key: str, block_counts: BlockCounts) -> RodCounts:
    """Calculate rod counts (tension rods, extension rods, ladder wire) for a component.

    Proto walls require vertical tension rods; CMU walls typically do not.  Rods
    are placed at regular intervals along the wall and at corners/control joints.
    Extension rods are used when the wall height exceeds a threshold.

    Parameters
    ----------
    segment : NormalizedSegment
        Segment containing the component.
    comp_key : str
        ``'ret'`` or ``'wot'``.
    block_counts : BlockCounts
        Block counts for the component (used to derive course count).

    Returns
    -------
    RodCounts
        Number of tension rods, extension rods and ladder wire length.
    """
    component = segment.get_component(comp_key)
    if component is None:
        return RodCounts()

    courses = block_counts.courses
    length_ft = segment.length_lf

    # Ladder wire: horizontal reinforcement each course along the length
    ladder_wire_lf = courses * length_ft

    if component.system.upper() != 'PROTO':
        # No tension rods for CMU walls; ladder wire still counted
        return RodCounts(tension_rods=0, extension_rods=0, ladder_wire_lf=ladder_wire_lf)

    # Number of rods along length: one at each interval plus one at the start
    # Example: a 30 ft wall with spacing 6 ft → rods at 0 ft, 6 ft, 12 ft, 18 ft, 24 ft, 30 ft → 6 rods
    n_intervals = math.floor(length_ft / REBAR_SPACING_PROTO_FT)
    tension_rods = n_intervals + 1

    # Add rods at each corner and control joint
    tension_rods += segment.labels.corner_count
    tension_rods += segment.labels.control_joint_count

    # Always include rods at both ends (if not already counted)
    # If length is exactly divisible by spacing, the above count already includes both ends
    # so no additional rods are needed here.

    # Extension rods: if the wall height exceeds the threshold, we need a second rod per tension rod
    extension_rods = 0
    if courses > EXTENSION_ROD_COURSE_THRESHOLD:
        extension_rods = tension_rods

    return RodCounts(
        tension_rods=tension_rods,
        extension_rods=extension_rods,
        ladder_wire_lf=ladder_wire_lf,
    )


def _calculate_grout_volume(segment: NormalizedSegment, comp_key: str, block_counts: BlockCounts) -> GroutVolume:
    """Calculate grout volume for a component based on block counts and system type.

    Each block cell is assumed to require a certain volume of grout (in cubic
    feet).  The fill factor differs between Proto and CMU systems.  Bond‑beam
    blocks and standard blocks are treated the same for grout purposes.  Half
    blocks contribute half a cell each.

    Parameters
    ----------
    segment : NormalizedSegment
        Segment containing the component.
    comp_key : str
        ``'ret'`` or ``'wot'``.
    block_counts : BlockCounts
        Block counts for the component.

    Returns
    -------
    GroutVolume
        The number of cells filled and the corresponding volume in cubic yards.
    """
    component = segment.get_component(comp_key)
    if component is None:
        return GroutVolume()

    # Determine grout fill factor based on system
    fill_factor_ft3 = (
        GRUOT_FILL_FACTOR_PROTO_FT3 if component.system.upper() == 'PROTO' else GRUOT_FILL_FACTOR_CMU_FT3
    )

    # Number of block cells filled: one per standard block, one per bond beam block,
    # and half per half block (two halves make a full block)
    cells_filled = block_counts.standard + block_counts.bond_beam + (block_counts.half * 0.5)

    volume_ft3 = cells_filled * fill_factor_ft3
    volume_cy = volume_ft3 / 27.0

    return GroutVolume(cells_filled=int(cells_filled), volume_cy=volume_cy)


def calculate_quantities(segment: NormalizedSegment) -> Dict[str, QuantityResults]:
    """Compute quantities for each component in a segment.

    This function orchestrates the block, rod and grout calculations for both
    retaining and wall‑on‑top components.  The return value is a dictionary
    containing one entry per component present in the segment.

    Parameters
    ----------
    segment : NormalizedSegment
        Segment to calculate quantities for.

    Returns
    -------
    dict
        A mapping from component key ('ret' or 'wot') to ``QuantityResults``.
    """
    results: Dict[str, QuantityResults] = {}
    for comp_key in ('ret', 'wot'):
        if segment.has_component(comp_key):
            bc = _calculate_block_counts(segment, comp_key)
            rc = _calculate_rod_counts(segment, comp_key, bc)
            gv = _calculate_grout_volume(segment, comp_key, bc)
            results[comp_key] = QuantityResults(block_counts=bc, rod_counts=rc, grout=gv)
    return results


__all__ = ["calculate_quantities"]