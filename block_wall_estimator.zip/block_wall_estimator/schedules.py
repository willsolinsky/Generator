"""
Schedule tables and constants for the block wall estimator.

Schedules define how often various items occur in a wall and how they depend on
wall height or system type.  These simplified schedules are placeholders for
the real tables used in production estimators; the values here are chosen to
provide reasonable output for demonstration and testing purposes.  Feel free
to adjust them to match your own standards or tie them into external data
sources.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


###############################################################################
# Block and rebar spacing constants
###############################################################################

# Bond beam spacing (courses): number of courses between bond beam rows.  A
# bond beam is a continuous horizontal course of blocks designed to tie the wall
# together.  In many designs, bond beams are spaced every 4 courses.
BOND_BEAM_SPACING_COURSES = 4

# Half blocks per corner per course: there are two half units per corner per
# course (left and right halves).  Since two halves make a full block, we count
# this as 1 half block per corner per course.
HALF_BLOCKS_PER_CORNER_PER_COURSE = 1

# For Proto (post‑tension) walls, vertical tension rods are placed at regular
# intervals along the wall length.  This constant defines the maximum spacing
# between rods in feet.  Additional rods may be added at corners and control
# joints.
REBAR_SPACING_PROTO_FT = 6.0

# For extended rods: when a Proto wall exceeds a certain height, rods are
# extended into the wall‑on‑top segment.  This constant defines the height
# threshold (courses) beyond which extension rods are required.  For example,
# if a retaining wall is taller than 7 ft (≈10.5 courses), extension rods are
# necessary to reach the cap level.  The value can be tuned based on
# engineering standards.
EXTENSION_ROD_COURSE_THRESHOLD = 12  # courses beyond which extension rods are needed


###############################################################################
# Grout fill factors
###############################################################################

# Grout fill factor (cubic feet) per block cell.  These factors approximate the
# amount of grout poured into each cell of a block.  Proto walls tend to have
# lower fill because of their post‑tension design; CMU walls usually have
# full‑grouted cells in bond‑beam and pilaster areas.  The values below are
# simplified and do not account for grout wastage or cleanouts.
GRUOT_FILL_FACTOR_PROTO_FT3 = 0.09
GRUOT_FILL_FACTOR_CMU_FT3 = 0.18


###############################################################################
# Footing schedule (placeholder)
###############################################################################

@dataclass
class FootingScheduleEntry:
    """A single entry in the footing schedule.

    Attributes
    ----------
    max_height_ft : float
        Maximum combined wall height that this entry covers.
    footing_width_ft : float
        Footing width in feet.
    footing_depth_ft : float
        Footing depth in feet.
    keyway_height_ft : float
        Height of any keyway in the footing (if applicable).
    """

    max_height_ft: float
    footing_width_ft: float
    footing_depth_ft: float
    keyway_height_ft: float


# Example footing schedule.  Real estimators use a matrix keyed by wall type,
# soil bearing capacity, seismic zone, etc.  For demonstration purposes, we
# assume two simple height buckets.
FOOTING_SCHEDULE: Dict[str, FootingScheduleEntry] = {
    "low": FootingScheduleEntry(max_height_ft=6.0, footing_width_ft=2.0, footing_depth_ft=0.75, keyway_height_ft=0.0),
    "high": FootingScheduleEntry(max_height_ft=10.0, footing_width_ft=2.5, footing_depth_ft=1.0, keyway_height_ft=0.5),
}


def lookup_footing(height_ft: float) -> FootingScheduleEntry:
    """Select a footing schedule entry based on wall height.

    This simplistic lookup picks the first schedule entry with ``max_height_ft``
    greater than or equal to the supplied height.  If no entry matches,
    the schedule with the highest height bucket is returned.

    Parameters
    ----------
    height_ft : float
        Combined wall height (retaining + wall‑on‑top).

    Returns
    -------
    FootingScheduleEntry
        The applicable schedule entry.
    """
    for entry in FOOTING_SCHEDULE.values():
        if height_ft <= entry.max_height_ft:
            return entry
    # Fallback to the highest bucket
    return FOOTING_SCHEDULE[max(FOOTING_SCHEDULE.keys())]


__all__ = [
    "BOND_BEAM_SPACING_COURSES",
    "HALF_BLOCKS_PER_CORNER_PER_COURSE",
    "REBAR_SPACING_PROTO_FT",
    "EXTENSION_ROD_COURSE_THRESHOLD",
    "GRUOT_FILL_FACTOR_PROTO_FT3",
    "GRUOT_FILL_FACTOR_CMU_FT3",
    "FootingScheduleEntry",
    "FOOTING_SCHEDULE",
    "lookup_footing",
]