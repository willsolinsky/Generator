"""
Block Wall Estimator
====================

This package implements a simplified estimator for concrete masonry walls (CMU and
Proto systems).  It converts raw Bluebeam take‑off rows into normalized wall
segments, computes block counts, rebar (rod) quantities, grout volumes, and
other derived quantities.  The implementation is guided by the
``block_wall_estimator_codex_spec.md`` document included in this repository.

The estimator is intentionally modular:

* ``parser`` handles extraction of meaningful data from free‑form label strings.
* ``models`` defines the core dataclasses used throughout the estimator.
* ``geometry`` contains helpers for converting heights to course counts and
  calculating lengths/areas.
* ``calc`` implements the quantity calculations (blocks, rods, grout, etc.).
* ``schedules`` exposes lookup tables for footing, rebar and other schedule‑based
  calculations.  These tables are simplified examples; real schedules should be
  configured from external data.
* ``aggregator`` rolls up quantities from one or more segments into summary
  outputs suitable for costing or proposal generation.

The package is designed to be self‑contained and free of external dependencies.
All data structures are simple ``dataclasses`` that can easily be serialized to
and from JSON/YAML for testing or integration with other tools.

For a demonstration of the estimator, run ``python -m block_wall_estimator``.
``__main__.py`` contains a small sample that parses a combined retaining/wall‑on
top segment, calculates quantities and prints a formatted summary.

Note that this implementation covers only a subset of the full estimator
described in the specification.  In particular, pilaster logic, cap lookups,
complete footing schedule derivation and many specialized material outputs are
omitted.  The structure, however, makes it straightforward to extend the
implementation as additional formulas become known.
"""

from .models import (  # noqa: F401
    LabelCounts,
    WallComponent,
    NormalizedSegment,
    BlockCounts,
    RodCounts,
    GroutVolume,
    QuantityResults,
)
from .parser import parse_description  # noqa: F401
from .calc import calculate_quantities  # noqa: F401
from .aggregator import aggregate_quantities  # noqa: F401

__all__ = [
    "LabelCounts",
    "WallComponent",
    "NormalizedSegment",
    "BlockCounts",
    "RodCounts",
    "GroutVolume",
    "QuantityResults",
    "parse_description",
    "calculate_quantities",
    "aggregate_quantities",
]