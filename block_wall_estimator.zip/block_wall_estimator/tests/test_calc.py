"""
Unit tests for quantity calculations.

These tests validate that the calculation engine produces consistent block counts,
rod counts and grout volumes for a sample Proto wall segment.  They use the
same sample data as the parser tests and derive expected values manually.
"""

import os
import sys
import unittest

# Ensure the package can be imported when running tests from the repository root
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from block_wall_estimator.parser import parse_description
from block_wall_estimator.calc import calculate_quantities


class TestCalculateQuantities(unittest.TestCase):
    def setUp(self):
        description = "E RET 8 PROTO 6.67 _ WOT 6 PROTO 6"
        length = 52.8098
        labels = ["Control Joint"]
        self.segment = parse_description(description, segment_id="S1", length_ft=length, labels=labels)
        self.results = calculate_quantities(self.segment)

    def test_block_counts_ret(self):
        ret = self.results['ret'].block_counts
        self.assertEqual(ret.courses, 11)
        self.assertEqual(ret.standard, 320)
        self.assertEqual(ret.bond_beam, 120)
        self.assertEqual(ret.half, 0)
        self.assertEqual(ret.total, 440)

    def test_block_counts_wot(self):
        wot = self.results['wot'].block_counts
        self.assertEqual(wot.courses, 9)
        self.assertEqual(wot.standard, 240)
        self.assertEqual(wot.bond_beam, 120)
        self.assertEqual(wot.half, 0)
        self.assertEqual(wot.total, 360)

    def test_rod_counts_proto(self):
        ret_rc = self.results['ret'].rod_counts
        wot_rc = self.results['wot'].rod_counts
        # Tension rods: floor(length/6)+1 + control joints
        self.assertEqual(ret_rc.tension_rods, 10)
        self.assertEqual(wot_rc.tension_rods, 10)
        # Extension rods: none (courses <= threshold)
        self.assertEqual(ret_rc.extension_rods, 0)
        self.assertEqual(wot_rc.extension_rods, 0)
        # Ladder wire LF
        # Retaining: 11 courses * 52.8098 LF
        self.assertAlmostEqual(ret_rc.ladder_wire_lf, 11 * 52.8098, places=4)
        # Wall‑on‑top: 9 courses * 52.8098 LF
        self.assertAlmostEqual(wot_rc.ladder_wire_lf, 9 * 52.8098, places=4)

    def test_grout_volume_proto(self):
        ret_gv = self.results['ret'].grout
        wot_gv = self.results['wot'].grout
        # Cells filled: standard + bond + half*0.5
        self.assertEqual(ret_gv.cells_filled, 440)
        self.assertEqual(wot_gv.cells_filled, 360)
        # Volume CY: cells * 0.09 ft3 / 27
        self.assertAlmostEqual(ret_gv.volume_cy, (440 * 0.09) / 27, places=6)
        self.assertAlmostEqual(wot_gv.volume_cy, (360 * 0.09) / 27, places=6)


if __name__ == '__main__':
    unittest.main()