"""
Unit tests for the Bluebeam description parser.

These tests verify that the parser produces correct ``NormalizedSegment``
instances for various input strings.  The sample test cases are derived from
the parity package described in ``block_wall_estimator_codex_spec.md``.
"""

import os
import sys
import unittest

# Ensure the package can be imported when running tests from the repository root
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from block_wall_estimator.parser import parse_description


class TestParser(unittest.TestCase):
    def test_parse_combined_proto_segment(self):
        description = "E RET 8 PROTO 6.67 _ WOT 6 PROTO 6"
        segment = parse_description(description, segment_id="S1", length_ft=52.8098, labels=["Control Joint"])
        # Check retaining component
        self.assertIsNotNone(segment.ret)
        self.assertEqual(segment.ret.type, 'RET')
        self.assertEqual(segment.ret.width_in, 8)
        self.assertEqual(segment.ret.system, 'PROTO')
        self.assertAlmostEqual(segment.ret.height_ft, 6.67, places=2)
        # Check wall‑on‑top component
        self.assertIsNotNone(segment.wot)
        self.assertEqual(segment.wot.type, 'WOT')
        self.assertEqual(segment.wot.width_in, 6)
        self.assertEqual(segment.wot.system, 'PROTO')
        self.assertAlmostEqual(segment.wot.height_ft, 6.0, places=2)
        # Check label counts
        self.assertEqual(segment.labels.control_joint_count, 1)
        self.assertEqual(segment.labels.corner_count, 0)
        self.assertEqual(segment.labels.miter_count, 0)
        self.assertEqual(segment.labels.end_count, 0)


if __name__ == '__main__':
    unittest.main()