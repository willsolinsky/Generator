"""
Demonstration entry point for the block wall estimator.

Run this module directly to parse a sample Bluebeam take‑off row, compute
quantities for retaining and wall‑on‑top components, and display the results.
The demonstration uses a combined segment with Proto blocks in both the
retaining and wall‑on‑top portions.  Feel free to modify the sample values to
experiment with different configurations.

Usage
-----

```
python -m block_wall_estimator
```

This will print out the parsed segment, the per‑component quantities, and
aggregate totals across both components.
"""

from __future__ import annotations

from pprint import pprint

from .parser import parse_description
from .calc import calculate_quantities
from .aggregator import aggregate_quantities


def main() -> None:
    # Sample input: combined retaining and wall‑on‑top Proto walls
    description = "E RET 8 PROTO 6.67 _ WOT 6 PROTO 6"
    length_ft = 52.8098
    labels = ["Control Joint"]

    # Parse the description into a normalized segment
    segment = parse_description(description, segment_id="S1", length_ft=length_ft, labels=labels)

    print("Normalized segment:")
    pprint(segment)
    print()

    # Calculate quantities for both components
    quantities = calculate_quantities(segment)

    # Print per‑component quantities
    for comp_key, qty in quantities.items():
        print(f"Quantities for {comp_key.upper()} component:")
        pprint(qty)
        print()

    # Aggregate totals across components
    totals = aggregate_quantities(quantities.values())
    print("Aggregated totals:")
    pprint(totals)


if __name__ == "__main__":
    main()