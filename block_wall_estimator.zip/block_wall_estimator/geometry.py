"""
Geometry utilities for the block wall estimator.

This module defines functions for converting wall heights to CMU courses and computing
block counts per linear foot.  These utilities are system agnostic: they operate
solely on dimensions and do not account for Proto vs CMU differences.  Those
differences are handled in ``calc`` via system‑specific factors.

Course heights are based on the nominal block height (8 inches for standard CMU).
Block lengths are assumed to be 16 inches long (including mortar joints).  These
values may be overridden by schedule lookups in the future.
"""

import math
from typing import Optional


# Constants for CMU dimensions in inches
BLOCK_HEIGHT_IN = 8  # Standard course height; Proto uses the same height
BLOCK_LENGTH_IN = 16  # Standard block length including mortar


def height_to_courses(height_ft: float) -> int:
    """Convert a wall height in feet to a whole number of block courses.

    Courses are counted by dividing the height (in inches) by the block height and
    rounding up.  For example, a 6.67 ft tall wall requires ``ceil(6.67 × 12 / 8)``
    courses.

    Parameters
    ----------
    height_ft : float
        Height of the wall in feet.

    Returns
    -------
    int
        Number of courses required.
    """
    return math.ceil((height_ft * 12) / BLOCK_HEIGHT_IN)


def blocks_per_row(length_ft: float) -> float:
    """Compute the number of blocks per row (course) for a given wall length.

    Block lengths are assumed to be 16 inches (1.333 ft) long.  The result
    is a floating‑point value; callers should round up to the nearest whole block.

    Parameters
    ----------
    length_ft : float
        Linear footage of the wall segment.

    Returns
    -------
    float
        Blocks required per row.
    """
    return length_ft / (BLOCK_LENGTH_IN / 12)


def blocks_per_linear_foot() -> float:
    """Return the number of blocks per linear foot.

    Since each block is 16 inches long, there are 12/16 = 0.75 blocks per foot.
    """
    return 12 / BLOCK_LENGTH_IN


__all__ = ["height_to_courses", "blocks_per_row", "blocks_per_linear_foot"]