# Block Wall Estimator (Python)

This package implements a simplified block‐wall estimating engine in pure Python.  It
is designed as a modular reference implementation that can be extended to match
the full functionality of your existing spreadsheet‐based estimator.  The code
parses Bluebeam take‑off labels, normalizes retaining and wall‐on‐top segments,
computes block counts, rod counts, grout volumes and aggregates results across
segments.

## Repository structure

* `models.py` – Dataclasses representing labels, wall components, normalized
  segments and quantity results.
* `parser.py` – Parses free‐form Bluebeam description strings into structured
  `NormalizedSegment` objects.
* `geometry.py` – Low‐level helpers for converting heights to block courses
  and determining blocks per linear foot.
* `schedules.py` – Placeholder schedule tables and constants (bond beam
  spacing, rod spacing, grout fill factors, footing schedule).  Replace or
  extend these with your own data.
* `calc.py` – Core calculation engine.  Computes block counts, rod counts
  (including extension rods for tall walls), ladder wire lengths and grout
  volumes for each wall component.
* `aggregator.py` – Sums quantities across multiple segments into a single
  dictionary of totals.
* `__main__.py` – Demonstration script.  Running `python -m block_wall_estimator`
  parses a sample combined Proto wall, computes quantities for the retaining and
  wall‐on‐top portions and prints a formatted summary.
* `tests/` – Unit tests for the parser and calculation logic.  Run `pytest`
  from the repository root to execute them.  Use these tests as a starting
  point for adding your own fixtures.

## Usage

```
# Parse a Bluebeam label into a normalized segment
from block_wall_estimator.parser import parse_description
from block_wall_estimator.calc import calculate_quantities
from block_wall_estimator.aggregator import aggregate_quantities

label = "E RET 8 PROTO 6.67 _ WOT 6 PROTO 6"
segment = parse_description(label, segment_id="S1", length_ft=52.81, labels=["Control Joint"])

# Compute quantities per component (ret and wot)
quantities = calculate_quantities(segment)

# Aggregate results across both components
totals = aggregate_quantities(quantities.values())

print(quantities)
print(totals)
```

## Extending the estimator

This implementation covers only a subset of the formulas described in the
`block_wall_estimator_codex_spec.md` specification.  To build a complete
estimator, consider adding:

* **Pilaster logic** – count pilasters per segment based on spacing and end
  conditions.
* **Footing concrete and keyway volumes** – use the `lookup_footing` function
  in `schedules.py` and compute cubic yards of concrete.
* **Cap calculations** – derive cap material types and quantities from the
  block type and system (Proto vs CMU).
* **Material aggregation by color/texture** – support stripes or accent bands.
* **Detailed rebar sizing** – implement a matrix that maps wall height to
  vertical and horizontal bar sizes/spacings.
* **Full QA rule engine** – validate input data and detect orphaned labels or
  malformed height tokens.

By keeping inputs, schedules, the calculation engine, and outputs in separate
modules, it becomes straightforward to adjust formulas or plug in external
configuration without changing core code.  Use the provided unit tests as a
template to create your own fixtures based on real workbook examples.

## Copying into your repository

To incorporate this estimator into your `Generator` repository:

1. **Create a new folder** called `block_wall_estimator` in the root of your
   repository.
2. Copy all files from this `block_wall_estimator` folder into the new
   directory in your repository.  Maintain the same file names and
   structure.
3. Commit the new files using the GitHub UI or your local Git client.  For
   example, using the web interface, navigate to the repository root,
   choose **Add file → Upload files**, drag‐and‐drop the `block_wall_estimator`
   folder, and commit the changes.
4. Optionally add the unit tests to your repository by placing the
   `block_wall_estimator/tests` folder next to your code and running
   `pytest` to verify that everything works in your environment.

Once committed, you can import the estimator in your backend scripts or
serverless functions.  Continue to extend the modules as you unravel more
formulas from your existing spreadsheet.