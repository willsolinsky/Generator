"""
Parser for Bluebeam description strings.

This module exposes a single function, ``parse_description``, which accepts a raw
description (subject) exported from Bluebeam, along with the measured linear
footage and any associated labels, and returns a ``NormalizedSegment``.  The
parser handles combined retaining/wall‑on‑top segments separated by ``" _ "``
and makes reasonable assumptions when tokens are missing.  It does not attempt
to derive footing codes or pilaster data; those will be handled by schedule
lookups in later stages.

The parser is tolerant of minor variations in formatting.  It ignores the
scheme prefix (e.g., ``"E"`` or ``"NW"``) at the beginning of the string, and
will treat unknown system tokens as system identifiers.  Heights may be
expressed as a single value or two values (low/high) separated by a slash;
the parser returns the average height.  Missing heights default to zero.
"""

from __future__ import annotations

import re
from typing import List, Optional, Tuple

from .models import LabelCounts, WallComponent, NormalizedSegment


def _is_number(token: str) -> bool:
    """Return True if the token represents a float number."""
    try:
        float(token)
        return True
    except ValueError:
        return False


def _parse_component_tokens(tokens: List[str]) -> Tuple[str, int, str, float]:
    """Parse a sequence of tokens representing a single wall component.

    The expected order is ``TYPE WIDTH [SYSTEM] [HEIGHT ...]``.  Heights may be
    provided as one or two numeric values.  If two heights are supplied, the
    function returns their average.  If no height is supplied, it returns 0.

    Parameters
    ----------
    tokens : list of str
        A list of tokens describing the component.

    Returns
    -------
    tuple
        A 4‑tuple ``(component_type, width_in, system, height_ft)``.
    """
    if len(tokens) < 2:
        raise ValueError(f"Insufficient tokens for component: {tokens}")

    comp_type = tokens[0].upper()
    try:
        width_in = int(tokens[1])
    except ValueError:
        raise ValueError(f"Invalid width token in component: {tokens[1]}")

    system = 'CMU'
    heights: List[float] = []

    # Remaining tokens may include system and/or heights
    for tok in tokens[2:]:
        if _is_number(tok):
            heights.append(float(tok))
        else:
            system = tok.upper()

    if len(heights) == 2:
        height_ft = sum(heights) / 2
    elif heights:
        height_ft = heights[0]
    else:
        height_ft = 0.0

    return comp_type, width_in, system, height_ft


def parse_description(
    description: str,
    segment_id: str,
    length_ft: float,
    labels: Optional[List[str]] = None,
) -> NormalizedSegment:
    """Parse a Bluebeam subject string into a normalized segment.

    This function splits the description on the delimiter ``" _ "`` to separate
    retaining and wall‑on‑top portions.  It strips any leading scheme token
    before parsing component tokens.  Label counts are tallied into a
    ``LabelCounts`` instance.

    Parameters
    ----------
    description : str
        Raw description (subject) exported from Bluebeam.
    segment_id : str
        Unique identifier to assign to the resulting segment.
    length_ft : float
        Linear footage associated with the take‑off row.
    labels : list of str, optional
        Any label values attached to the segment (e.g., 'Corner', 'Control Joint').

    Returns
    -------
    NormalizedSegment
        Structured representation of the segment.
    """

    # Initialize label counts
    lbl_counts = LabelCounts()
    if labels:
        for lbl in labels:
            low = lbl.strip().lower()
            if 'corner' in low:
                lbl_counts.corner_count += 1
            elif 'miter' in low:
                lbl_counts.miter_count += 1
            elif 'control joint' in low or 'control' in low:
                lbl_counts.control_joint_count += 1
            elif 'end' in low:
                lbl_counts.end_count += 1

    # Split on " _ " to separate components
    parts = [p.strip() for p in description.split(' _ ')]

    # Helper to parse one part into a WallComponent
    def parse_part(part: str) -> Optional[WallComponent]:
        if not part:
            return None
        tokens = part.split()
        # Remove scheme prefix (e.g. 'E', 'NW') if present
        if tokens and tokens[0].upper() not in ('RET', 'WOT'):
            tokens = tokens[1:]
        if not tokens:
            return None
        comp_type, width_in, system, height_ft = _parse_component_tokens(tokens)
        return WallComponent(type=comp_type, width_in=width_in, system=system, height_ft=height_ft)

    ret_component: Optional[WallComponent] = None
    wot_component: Optional[WallComponent] = None

    # Parse first part (could be RET or WOT)
    if parts:
        first_comp = parse_part(parts[0])
        if first_comp:
            if first_comp.type == 'RET':
                ret_component = first_comp
            else:
                wot_component = first_comp

    # Parse second part if present
    if len(parts) > 1:
        second_comp = parse_part(parts[1])
        if second_comp:
            if second_comp.type == 'RET' and ret_component is None:
                ret_component = second_comp
            elif second_comp.type == 'WOT' and wot_component is None:
                wot_component = second_comp
            else:
                # In rare cases the description may list components out of order; assign accordingly
                if second_comp.type == 'RET':
                    ret_component = second_comp
                else:
                    wot_component = second_comp

    # Return normalized segment
    return NormalizedSegment(
        segment_id=segment_id,
        raw_label=description,
        ret=ret_component,
        wot=wot_component,
        length_lf=length_ft,
        labels=lbl_counts,
    )


__all__ = ["parse_description"]